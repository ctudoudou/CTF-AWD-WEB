<br>
<div><iframe id="frm1" src="http://passport.shopex.cn/index.php?ctl=iframeent&act=index&url=<?php echo $link_url;?>&t=<?php echo $nowtime;?>" frameborder="0" allowtransparency='true' scrolling='auto' width='666' height='410'></iframe>
</div><br>
<a href="<?php echo $admin_url;?>"><b>跳过激活流程，立即进入管理后台</b></a>